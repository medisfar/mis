<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class Ivaleur extends Model
{
	public $guarded=['id'];
	public $timestamps=false;

	public static function tab(){
	    return Bailleur::pluck('code','id')->prepend('','');
        }
public function bailleur_projets(){
	return $this->hasMany(\App\Models\Bailleur_i);
}

}
