<div>

@include('livewire.errors')
<div class="row">
<x-select nc="12" label="Prefecture" fd="prefecture_id" :options="\App\Models\Prefecture::tab()"></x-select>
<x-field nc="6" label="Code" fd="code"></x-field>
<x-field nc="6" label="Nom_ssprefecture" fd="nom_ssprefecture"></x-field>
<x-select nc="12" label="Type" fd="l_type" :options="\App\Models\Ssprefecture::types()"></x-select>
<button class="btn btn-sm btn-success"  wire:click="storeSsprefecture()">Enregistrer</button>

</div></div>