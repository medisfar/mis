<x-slot name="titre">Missions</x-slot>

              <x-slot name="stitre">@include('livewire.projet.menu')</x-slot>
<div>
<table  class="table table-bordered">
<tr>
	<th>Libelle</th>
	<td>{{$mission->libelle}}</td>
</tr>
<tr>
	<th>Description</th>
	<td>{{$mission->description}}</td>
</tr>
</table>
<a class="btn btn-sm btn-primary" href="{{route('projet.missions')}}">Liste</a>
<a class="btn btn-sm btn-primary" href="{{route('projet.missions.edit',$mission->id)}}"><i class="fas fa-edit"></i></button>
 <button  class="btn btn-sm btn-danger" wire:click="destroyMission({{$mission->id}})"><i class="fas fa-trash"></i></button>  
</div>